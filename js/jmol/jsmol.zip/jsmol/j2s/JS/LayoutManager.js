Clazz.declarePackage ("JS");
c$ = Clazz.declareType (JS, "LayoutManager");
