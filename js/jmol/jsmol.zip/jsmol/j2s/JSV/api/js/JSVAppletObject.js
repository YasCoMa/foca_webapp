Clazz.declarePackage ("JSV.api.js");
Clazz.load (["javajs.api.js.JSAppletObject"], "JSV.api.js.JSVAppletObject", null, function () {
Clazz.declareInterface (JSV.api.js, "JSVAppletObject", javajs.api.js.JSAppletObject);
});
